from django.urls import re_path, path
from django.conf.urls import url
from channels.routing import ProtocolTypeRouter, URLRouter
from . import consumers

websocket_urlpatterns = URLRouter([
    path('ws/room/<int:room_id>/', consumers.ChatConsumer.as_asgi()),
])
