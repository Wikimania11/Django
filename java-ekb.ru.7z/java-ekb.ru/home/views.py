from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponse
from django.contrib.auth import logout
import json
import time
import base64
from django.core.files.base import ContentFile


TEMPLATE_DIRS = (
    'os.path.join(BASE_DIR,"templates"),'
)


def index(request):
    error = ''
    if request.method == 'POST':
        json_1 = json.loads(request.body)
        print(json_1)
        phone_number = json_1.get('phone')
        password = json_1.get('password')
        cursor = connection.cursor()
        cursor.execute(f"SELECT password FROM User WHERE phone = {phone_number}")
        pswd = cursor.fetchone()
        print(pswd)
        if pswd != None:
            if pswd[0] == password:
                # переход на диалоги

                # сохранение в сессию
                request.session["phone_number"] = phone_number

                print(1)
                cursor.execute(f"SELECT id,name,welcome_msg,image_link FROM User WHERE phone = {phone_number}")
                psd = cursor.fetchone()
                data = json.dumps({"status": 0, "id": psd[0], "message": "переход на диалоги","name":psd[1],"welcome_msg":psd[2],"image_link":psd[3],})
                # запись файлов куки
                #response.set_cookie(key='logged', value=True)

                return HttpResponse(data, content_type="application/json;charset=UTF-8")

            else:
                # ошибку про неверный пароль
                print(2)
                data = json.dumps({"status": 1, "message": "Введён неверный пароль"})
                return HttpResponse(data, content_type="application/json;charset=UTF-8")
        else:

            # сохраняем в сессию
            request.session["phone_number"] = phone_number
            cursor.execute(f"SELECT id FROM User WHERE phone = {phone_number}")
            psd = cursor.fetchone()
            cursor.execute(f"INSERT INTO `User` (phone, password) VALUES ('{phone_number}', '{password}')")
            data = json.dumps({"status": 2, "message": "Переход на страницу регистрации", "id": psd})
            # запись файлов куки
            #response.set_cookie(key='logged', value=True)

            return HttpResponse(data, content_type="application/json;charset=UTF-8")
            print(3)

    return render(request, "index.html")


def edit(request):  # метод входа
    error = ''  # переменная для ошибки
    if request.method == 'POST':
        json_1 = json.loads(request.body)
        print(json_1)
        name = json_1.get('name')  # имя
        welcome_msg = json_1.get('welcome_msg')  # приветственное сообщение
        image_link = json_1.get('image_link')  # строка двоичных данных
        cursor = connection.cursor()
        phone = request.session.get("phone_number")
        cursor.execute(f"UPDATE `User` SET name='{name}' , welcome_msg = '{welcome_msg}' WHERE phone = '{phone}'")
        # поле вставки картинки
        #image_data = image_link.split(',', maxsplit=1)[1]  # Берем всё что находится после запятой, то есть сам Base64
        #image_name = str(request.session.get("phone_number"))
        #imgSaveURL = '/var/www/web/sites/java-ekb.ru/media/' + image_name + '.jpg' #не трогать путь, а то все рухнет!
        #with open(imgSaveURL, "wb") as fh:
        #    fh.write(base64.decodestring(image_data.encode()))  # Получите из запроса файловый объект и скопируйте его в файл
        cursor.execute(f"UPDATE `User` SET image_link='{image_link}' WHERE phone = '{phone}'")

        cursor.execute(f"SELECT id FROM User WHERE phone = '{phone}'")
        psd = cursor.fetchone()
        data = json.dumps({"status": 0, "message": "переход на диалоги", "id": psd[0]})

        # Your code here...
        #transaction.commit_unless_managed(using='sabygram')
        #connection.commit() #сохранить в базе

        return HttpResponse(data, content_type="application/json;charset=UTF-8")
    return render(request, "index.html")  # возможно будет ругаться на это


def dialogs(request):
    cursor = connection.cursor()
    # ИЗМЕНЕНИЕ ГРУППЫ
    if request.method == 'POST':
        # проверка наличия сессии
        if "phone_number" not in request.session:
            print("Redirect INDEX!")
            return redirect('index')

        json_1 = json.loads(request.body)
        print(json_1)
        index = json_1.get('status')
        if index == 0: # изменение группы 0 общие, 1 громкие, 2 тихие
            id_pair = json_1.get('id_pair')
            id_user_to_change = json_1.get('user_id')
            group_number = json_1.get('group_number')
            cursor.execute(f"SELECT User1 FROM Pair WHERE id = {id_pair}")
            user1 = cursor.fetchone()[0]
            if user1 == id_user_to_change:
                cursor.execute(f"UPDATE Pair SET relationship2_1 = {group_number} WHERE id = {id_pair}")
            else:
                cursor.execute(f"UPDATE Pair SET relationship1_2 = {group_number} WHERE id = {id_pair}")
        elif index == 70:
             phone = request.session.get("phone_number")
             cursor.execute(f"SELECT id,name,welcome_msg,image_link FROM User WHERE phone = {phone}")
             psd = cursor.fetchone()
             data = json.dumps({"id": psd[0], "message": "переход на диалоги","name":psd[1],"welcome_msg":psd[2],"image_link":psd[3]})
             return HttpResponse(data, content_type="application/json;charset=UTF-8")

        elif index == 80:
            phone = request.session.get("phone_number")
            cursor.execute(f"SELECT id FROM User WHERE phone = {phone}")
            id_user = cursor.fetchone()[0]
            cursor.execute(
                f"SELECT name, image_link, last_msg.* FROM User INNER JOIN ( SELECT text, date_time, is_read, direction1_2, id_pair, CASE WHEN User1 = {id_user} THEN USER2 ELSE USER1 END as Receiver, CASE WHEN User1 = {id_user} THEN relationship1_2 ELSE relationship2_1 END as Relationship FROM Message INNER JOIN Pair ON Message.id_pair = Pair.id WHERE (id_pair, date_time) IN ( SELECT id_pair, MAX(date_time) as last_time FROM Message WHERE id_pair IN ( SELECT id FROM Pair WHERE User1 = {id_user} OR User2 = {id_user} ) GROUP BY id_pair ) ) as last_msg ON last_msg.Receiver = User.id")
            dialogs_list = cursor.fetchall()  # принятие всех данных в переменную
            # берем данные и сортируем по id пользователя (громкие тихие общие)
            # data = [[], [], [], user_info]
            data = [[], [], []]

            for dialog in dialogs_list:
                if dialog[8] == 0:
                    # print(dialog[0], "Громкий")
                    data[0].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2],
                                    "img": dialog[1], "timing": str(dialog[3])})
                elif dialog[8] == 1:
                    # print(dialog[0], "Общий")
                    data[1].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2],
                                    "img": dialog[1], "timing": str(dialog[3])})
                elif dialog[8] == 2:
                    # print(dialog[0], "Тихий")
                    data[2].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2],
                                    "img": dialog[1], "timing": str(dialog[3])})
                else:
                    print('Ошибка Relationship =', dialog[8], 'для', dialog)
            datajson = json.dumps(data)
            # print(data[0], 'data0/n', data[1], 'data1/n', data[2], 'data2/n')
            return HttpResponse(datajson, content_type="application/json;charset=UTF-8")


        elif index == 99:  # выход из сессии
            print("До выхода", request.session)
            del request.session['phone_number']
            print("Delete phone from session")
            # request.session.flush() #удаляет данные текущего сеанса и удаляет cookie сеанса
            # request.session.set_expiry(1) # установка времени жизни сессии - 1 секунда
            if request.session.get("phone_number") is None:
                data = json.dumps({"status": 1})
            else:
                data = json.dumps({"status": 0})
            logout(request)  # выход
            print("Logout")
            request.session.flush()
            print("После выхода", request.session)
            return HttpResponse(data, content_type="application/json;charset=UTF-8")

        elif index == 1:  # редактирование профиля
            name = json_1.get('name')  # имя
            welcome_msg = json_1.get('welcome_msg')  # приветственное сообщение
            image_link = json_1.get('image_link')  # строка двоичных данных
            phone = request.session.get("phone_number")
            cursor.execute(f"UPDATE `User` SET name='{name}' , welcome_msg = '{welcome_msg}' WHERE phone = '{phone}'")
            # поле вставки картинки
            # image_data = image_link.split(',', maxsplit=1)[1]  # Берем всё что находится после запятой, то есть сам Base64
            # image_name = str(request.session.get("phone_number"))
            # imgSaveURL = '/var/www/web/sites/java-ekb.ru/media/' + image_name + '.jpg' #не трогать путь, а то все рухнет!
            # with open(imgSaveURL, "wb") as fh:
            #    fh.write(base64.decodestring(image_data.encode()))  # Получите из запроса файловый объект и скопируйте его в файл
            if image_link != "":
                cursor.execute(f"UPDATE `User` SET image_link='{image_link}' WHERE phone = '{phone}'")
                print(55)
            cursor.execute(f"SELECT id FROM User WHERE phone = '{phone}'")
            psd = cursor.fetchone()
            data = json.dumps({"status": 0, "message": "переход на диалоги", "id": psd[0]})

            # Your code here...
            #transaction.commit_unless_managed(using='sabygram')
            #connection.commit()  # сохранить в базе

            return HttpResponse(data, content_type="application/json;charset=UTF-8")
        elif index == 2: #dialogi
            id_pair = json_1.get('id_pair')
            id_user = json_1.get('my_id')
            cursor.execute(f"SELECT User1 FROM Pair WHERE id={id_pair}")
            psd = cursor.fetchone()
            if psd[0] == id_user:
               status = 1
            else:
            	status = 0
            print(id_pair)
            cursor.execute(
                f"SELECT text, date_time, direction1_2 FROM Message WHERE (id_pair ={id_pair}) ORDER BY date_time")
            messages = cursor.fetchall()
            print(messages)
            data34 = []
            for message in messages:
                data34.append({'message': message[0], 'time': str(message[1]), 'direction': message[2], 'status': status})
            data33 = json.dumps(data34)
            return HttpResponse(data33, content_type="application/json;charset=UTF-8")

    # сообщения в диалоге


    #cursor.execute(f"SELECT name, welcome_msg, image_link FROM User WHERE id = {id_user}")
    #user_info = cursor.fetchone()

    # old version
    # "SELECT name, image_link, last_msg.* FROM User
    # INNER JOIN ( SELECT text, date_time, is_read, direction1_2, CASE WHEN User1 = {id_user} THEN USER2 ELSE USER1 END as Receiver,
    # CASE WHEN User1 = {id_user} THEN relationship1_2 ELSE relationship2_1 END as Relationship
    # FROM Message INNER JOIN Pair ON Message.id_pair = Pair.id
    # WHERE (id_pair, date_time) IN ( SELECT id_pair, MAX(date_time) as last_time
    # FROM Message WHERE id_pair IN ( SELECT id FROM Pair WHERE User1 = {id_user} OR User2 = {id_user} )
    # GROUP BY id_pair ) ) as last_msg
    # ON last_msg.Receiver = User.id"

    return render(request, "index.html")

    """
    for dialog in dialogs_list:
       if dialog[7] == 0:
           print(dialog[0], "Громкий")
           data[0].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[7] == 1:
           print(dialog[0], "Общий")
           data[1].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[7] == 2:
           print(dialog[0], "Тихий")
           data[2].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       else:
           print('Ошибка Relationship =', dialog[7], 'для', dialog)
    datajson = json.dumps(data)
    print(data[0], 'data0/n', data[1], 'data1/n', data[2], 'data2/n')
    return HttpResponse(datajson, content_type="application/json;charset=UTF-8")
    """
    # ('Иосиф Сталин', '/var/www/web/sites/java-ekb.ru/media/9521499412.jpg', 'А хочешь про коммунизм расскажу?', datetime.datetime(2021, 7, 20, 21, 12), 0, 1, 20, 1)
    # [ 0[Г] 1[О] 2[Т] ]
    # data = json.dumps({"dialog-img": 0, "dialog-name": "name", "dialog-message": "", "dialog-timing": "datetime"})
    # return render(request, "index.html")

"""
def chatapp(request):
    json_1 = json.loads(request.session)
    User1_ID
    User2_ID
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM Message WHERE Message.id_pair IN ( SELECT id FROM Pair WHERE (User1 = {User1_ID} OR User1 = {User2_ID}) AND (User2 = {User1_ID} OR User2 = {User2_ID}) ) ORDER BY date_time")

    return HttpResponse(#, content_type="application/json;charset=UTF-8")
"""


def contacts(request):
    error = ''  # переменная для ошибки
    if request.method == 'POST':
        json_1 = json.loads(request.body)
        print(json_1)
        index = json_1.get('status')
        if index == 1:
            # метод поиска контакта
            phone_number = json_1.get('phone')
            cursor = connection.cursor()
            cursor.execute(f"SELECT id, name, image_link FROM User WHERE phone = {phone_number}")
            pswd = cursor.fetchone()
            if pswd == None:
                data = json.dumps({"status": 0, "message": "Пользователь не найден"})
                return HttpResponse(data, content_type="application/json;charset=UTF-8")
            else:
                data = json.dumps({"status": 1, "message": "Пользователь найден", "id": pswd[0], "name": pswd[1], "image_link": pswd[2]})
                return HttpResponse(data, content_type="application/json;charset=UTF-8")
        else:
            # метод добавления контакта
            phone = request.session.get("phone_number")
            cursor = connection.cursor()
            cursor.execute(f"SELECT id FROM User WHERE phone = {phone}")
            id_user = cursor.fetchone()[0]
            error = ''  # переменная для ошибки
            json_1 = json.loads(request.body)
            id_user2 = json_1.get('user2_id')
            cursor = connection.cursor()
            cursor.execute(f"INSERT INTO Pair (User1, User2, relationship1_2, relationship2_1) VALUES ({id_user}, {id_user2}, 0, 0)")
            cursor.execute(f"SELECT id FROM Pair WHERE User1 = {id_user} AND User2 = {id_user2}")
            id_dialog = cursor.fetchone()
            cursor.execute(f"SELECT welcome_msg FROM User WHERE id = {id_user}")
            welcome_msg1 = cursor.fetchone()
            cursor.execute(f"SELECT welcome_msg FROM User WHERE id = {id_user2}")
            welcome_msg2 = cursor.fetchone()
            cursor.execute(f"INSERT INTO Message (id_pair, text, is_read, direction1_2) VALUES ({id_dialog[0]}, '{welcome_msg1[0]}', 1, 0)")
            time.sleep(1)
            cursor.execute(f"INSERT INTO Message (id_pair, text, is_read, direction1_2) VALUES ({id_dialog[0]}, '{welcome_msg2[0]}', 1, 1)")
            data = json.dumps({"status": 1, "message": "Пользователь добавлен", "dialog_id": id_dialog[0]})
            return HttpResponse(data, content_type="application/json;charset=UTF-8")
    return render(request, "index.html")





