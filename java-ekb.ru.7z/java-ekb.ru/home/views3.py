from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponse
from .models import Auth
from .forms import AuthForm

TEMPLATE_DIRS = (
    'os.path.join(BASE_DIR,"templates"),'
)


def index(request):
    error = ''
    if request.method == 'POST':
        print("POST !")
        form = AuthForm(request.POST)
        if form.is_valid():
            phone_number = form.cleaned_data["phone_number"]
            password = form.cleaned_data["password"]

            print("Base D")
            cursor = connection.cursor()
            cursor.execute(f"INSERT INTO User (telefon, password) VALUES  ({phone_number}, {password})")
            print("Success save")

            # print(phone_number, password)

            # data = Auth.objects.filter(phone_number=phone_number, password=password)
            # if data:  # Если нашёлся пользователь с таким телефоном и паролем
            #     # print("Такой пользователь существует => ВХОД")
            #     request.session["phone_number"] = phone_number
            #     request.session["password"] = password
            #
            #     if data.filter(nickname=''):  # Если пользователь ещё не указывал своё имя
            #         response = redirect('edit')
            #         # print("Имя ещё не задано")
            #     else:  # Если имя уже задано => переадресация на страницу с диалогами
            #         response = redirect('home')
            #         # print("Имя уже задано")
            #
            #     # Тест сохранения в куки
            #     response.set_cookie("phone_number", phone_number)
            #     response.set_cookie("password", password)
            #
            #     return response
            #
            # else:  # Если не нашлось пользователя с таким телефоном и паролем
            #     if Auth.objects.filter(phone_number=phone_number):  # Проверка что такой телефон есть в БД
            #         error = "Неправильный пароль"  # Если есть то значит пользователь ввёл неправильный пароль
            #     else:  # Если вообще нету никаких данных о пользователе => регистрируем его
            #         form.save()
            #         return redirect('edit')

        else:
            error = 'Некорректные данные'

    form = AuthForm()
    context = {
        'form': form,
        'error': error
    }

    # return render(request, 'main.html', context)

	
    return render(request, "index.html")
	
# Create your views here.
