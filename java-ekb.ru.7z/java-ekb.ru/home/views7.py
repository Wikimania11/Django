from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponse
import json
import base64
from django.core.files.base import ContentFile

TEMPLATE_DIRS = (
    'os.path.join(BASE_DIR,"templates"),'
)


def index(request):
    error = ''
    if request.method == 'POST':
        json_1 = json.loads(request.body)
        print(json_1)
        phone_number = json_1.get('phone')
        password = json_1.get('password')
        cursor = connection.cursor()
        cursor.execute(f"SELECT password FROM User WHERE phone = {phone_number}")
        pswd = cursor.fetchone()
        print(pswd)
        if pswd != None:
            if pswd[0] == password:
                # переход на диалоги

                # сохранение в сессию
                request.session["phone_number"] = phone_number

                print(1)
                cursor.execute(f"SELECT name,welcome_msg,image_link FROM User WHERE phone = {phone_number}")
                psd = cursor.fetchone()
                data = json.dumps({"status": 0, "message": "переход на диалоги","name":psd[0],"welcome_msg":psd[1],"image_link":psd[2]})
                return HttpResponse(data, content_type="application/json;charset=UTF-8")
            else:
                # ошибку про неверный пароль
                print(2)
                data = json.dumps({"status": 1, "message": "Введён неверный пароль"})
                return HttpResponse(data, content_type="application/json;charset=UTF-8")
        else:

            # сохраняем в сессию
            request.session["phone_number"] = phone_number

            cursor.execute(f"INSERT INTO `User` (phone, password) VALUES ('{phone_number}', '{password}')")
            data = json.dumps({"status": 2, "message": "Переход на страницу регистрации"})
            return HttpResponse(data, content_type="application/json;charset=UTF-8")
            print(3)

    return render(request, "index.html")


def edit(request):  # метод входа
    error = ''  # переменная для ошибки
    if request.method == 'POST':
        json_1 = json.loads(request.body)
        print(json_1)
        name = json_1.get('name')  # имя
        welcome_msg = json_1.get('welcome_msg')  # приветственное сообщение
        image_link = json_1.get('image_link')  # строка двоичных данных
        cursor = connection.cursor()
        phone = request.session.get("phone_number")
        cursor.execute(f"UPDATE `User` SET name='{name}' , welcome_msg = '{welcome_msg}' WHERE phone = '{phone}'")
        # поле вставки картинки
        #image_data = image_link.split(',', maxsplit=1)[1]  # Берем всё что находится после запятой, то есть сам Base64
        #image_name = str(request.session.get("phone_number"))
        #imgSaveURL = '/var/www/web/sites/java-ekb.ru/media/' + image_name + '.jpg' #не трогать путь, а то все рухнет!
        #with open(imgSaveURL, "wb") as fh:
        #    fh.write(base64.decodestring(image_data.encode()))  # Получите из запроса файловый объект и скопируйте его в файл
        if image_link != "": 
           cursor.execute(f"UPDATE `User` SET image_link='{image_link}' WHERE phone = '{phone}'")
        data = json.dumps({"status": 0, "message": "переход на диалоги"})

        # Your code here...
        transaction.commit_unless_managed(using='sabygram')
        connection.commit() #сохранить в базе

        return HttpResponse(data, content_type="application/json;charset=UTF-8")
    return render(request, "index.html")  # возможно будет ругаться на это

def dialogs(request):
    phone = request.session.get("phone_number")
    cursor = connection.cursor()
    cursor.execute(f"SELECT id FROM User WHERE phone = {phone}")
    id_user = cursor.fetchone()[0]

    #cursor.execute(f"SELECT name, welcome_msg, image_link FROM User WHERE id = {id_user}")
    #user_info = cursor.fetchone()

    cursor.execute(
        f"SELECT name, image_link, last_msg.* FROM User INNER JOIN ( SELECT text, date_time, is_read, direction1_2, id_pair, CASE WHEN User1 = {id_user} THEN USER2 ELSE USER1 END as Receiver, CASE WHEN User1 = {id_user} THEN relationship1_2 ELSE relationship2_1 END as Relationship FROM Message INNER JOIN Pair ON Message.id_pair = Pair.id WHERE (id_pair, date_time) IN ( SELECT id_pair, MAX(date_time) as last_time FROM Message WHERE id_pair IN ( SELECT id FROM Pair WHERE User1 = {id_user} OR User2 = {id_user} ) GROUP BY id_pair ) ) as last_msg ON last_msg.Receiver = User.id")

    # old version
    # "SELECT name, image_link, last_msg.* FROM User
    # INNER JOIN ( SELECT text, date_time, is_read, direction1_2, CASE WHEN User1 = {id_user} THEN USER2 ELSE USER1 END as Receiver,
    # CASE WHEN User1 = {id_user} THEN relationship1_2 ELSE relationship2_1 END as Relationship
    # FROM Message INNER JOIN Pair ON Message.id_pair = Pair.id
    # WHERE (id_pair, date_time) IN ( SELECT id_pair, MAX(date_time) as last_time
    # FROM Message WHERE id_pair IN ( SELECT id FROM Pair WHERE User1 = {id_user} OR User2 = {id_user} )
    # GROUP BY id_pair ) ) as last_msg
    # ON last_msg.Receiver = User.id"

    dialogs_list = cursor.fetchall()  # принятие всех данных в переменную
    # берем данные и сортируем по id пользователя (громкие тихие общие)
   # data = [[], [], [], user_info]
    data = [[], [], []]

    for dialog in dialogs_list:
       if dialog[8] == 0:
           # print(dialog[0], "Громкий")
           data[0].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[8] == 1:
           # print(dialog[0], "Общий")
           data[1].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[8] == 2:
           # print(dialog[0], "Тихий")
           data[2].append({"id_pair": dialog[6], "id": dialog[7], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       else:
           print('Ошибка Relationship =', dialog[8], 'для', dialog)
    datajson = json.dumps(data)
    # print(data[0], 'data0/n', data[1], 'data1/n', data[2], 'data2/n')
    return HttpResponse(datajson, content_type="application/json;charset=UTF-8")

    """
    for dialog in dialogs_list:
       if dialog[7] == 0:
           print(dialog[0], "Громкий")
           data[0].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[7] == 1:
           print(dialog[0], "Общий")
           data[1].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       elif dialog[7] == 2:
           print(dialog[0], "Тихий")
           data[2].append({"id": dialog[6], "name": dialog[0], "lastMessage": dialog[2], "img": dialog[1], "timing": str(dialog[3])})
       else:
           print('Ошибка Relationship =', dialog[7], 'для', dialog)
    datajson = json.dumps(data)
    print(data[0], 'data0/n', data[1], 'data1/n', data[2], 'data2/n')
    return HttpResponse(datajson, content_type="application/json;charset=UTF-8")
    """
    # ('Иосиф Сталин', '/var/www/web/sites/java-ekb.ru/media/9521499412.jpg', 'А хочешь про коммунизм расскажу?', datetime.datetime(2021, 7, 20, 21, 12), 0, 1, 20, 1)
    # [ 0[Г] 1[О] 2[Т] ]
    # data = json.dumps({"dialog-img": 0, "dialog-name": "name", "dialog-message": "", "dialog-timing": "datetime"})
    # return render(request, "index.html")

"""
def chatapp(request):
    json_1 = json.loads(request.session)
    User1_ID
    User2_ID
    cursor = connection.cursor()
    cursor.execute(f"SELECT * FROM Message WHERE Message.id_pair IN ( SELECT id FROM Pair WHERE (User1 = {User1_ID} OR User1 = {User2_ID}) AND (User2 = {User1_ID} OR User2 = {User2_ID}) ) ORDER BY date_time")

    return HttpResponse(#, content_type="application/json;charset=UTF-8")
"""
