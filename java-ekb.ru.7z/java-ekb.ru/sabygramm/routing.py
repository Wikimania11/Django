from channels.routing import ProtocolTypeRouter, URLRouter

from home.routing import websocket_urlpatterns

application = ProtocolTypeRouter({
    'websocket': websocket_urlpatterns,
})
